package com.codingdojo.displaydate.controllers;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DateController {
	@RequestMapping("/")
	public String index(Model model) {
		return "index.jsp";
	}
	
	@RequestMapping("/date")
	public String date(Model model) {
		Date d = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE, 'the' F 'of' MMMM, YYYYY");
		String formattedDate = sdf.format(d);
		model.addAttribute("date", formattedDate);
		return "date.jsp";
	}
	
	@RequestMapping("/time")
	public String time(Model model) {
		Date d = new java.util.Date();
		SimpleDateFormat sdf = new SimpleDateFormat("h:mm a");
		String formattedTime = sdf.format(d);
		model.addAttribute("time", formattedTime);
		return "time.jsp";
	}
}
